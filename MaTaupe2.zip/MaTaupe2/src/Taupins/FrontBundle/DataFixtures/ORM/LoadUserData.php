<?php

namespace Taupins\FrontBundle\DataFixtures\ORM;

use Doctrine\Common\DataFixtures\FixtureInterface;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\DependencyInjection\ContainerAwareInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Taupins\FrontBundle\Entity\User;
use Doctrine\Common\DataFixtures\OrderedFixtureInterface;
use Doctrine\Common\DataFixtures\AbstractFixture;


class LoadUserData extends AbstractFixture implements OrderedFixtureInterface
{
	const MAX_NB_USERS = 20;

	/**
	 * @var ContainerInterface
	 */
	private $container;

	/**
	 * {@inheritdoc}
	 */
	public function setContainer(ContainerInterface $container = null)
	{
		$this->container = $container;
	}

	public function load(ObjectManager $manager)
	{
		$faker = \Faker\Factory::create();

		for ($i = 0; $i<self::MAX_NB_USERS; ++$i)
		{
			$user = new User();
			$user->setUsername($faker->username);
			$user->setEmail($faker->email);
			$user->setPlainPassword($faker->password);
			$user->setEnabled(true);

			$manager->persist($user);

			$this->addReference('user'.$i, $user);
		}

		$user = new User();
		$user->setUsername('user');
		$user->setEmail($faker->email);
		$user->setPlainPassword($faker->password);
		$user->setEnabled(true);

		$manager->persist($user);

		$manager->flush();
	}

	public function getOrder()
	{
		return 1;
	}
}