<?php

namespace Taupins\FrontBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Taupins\FrontBundle\Entity\Status;
use Taupins\FrontBundle\Entity\Comment;
use FOS\UserBundle\Model\User as BaseUser;

/**
 * User
 *
 * @ORM\Table(name="user")
 * @ORM\Entity(repositoryClass="Taupins\FrontBundle\Repository\UserRepository")
 */
class User extends BaseUser
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\OneToMany(targetEntity="Status", mappedBy="user")
     */
    protected $statuses;

    /**
     * @ORM\ManyToMany(targetEntity="User", inversedBy="friendsWithMe")
     * @ORM\JoinTable(
     *      name="friends",
     *      joinColumns={@ORM\JoinColumn(name="user_id", referencedColumnName="id")},
     *      inverseJoinColumns={
     *            @ORM\JoinColumn(name="friend_user_id",
     *                            referencedColumnName="id")
     *      }
     * )
     **/
    private $friends;

    /**
     * @ORM\ManyToMany(targetEntity="User", mappedBy="friends")
     **/
    private $friendsWithMe;

    /**
     * @ORM\OneToMany(targetEntity="Comment", mappedBy="user")
     */
    protected $comments;

    


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set username
     *
     * @param string $username
     *
     * @return User
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->statuses = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Add status
     *
     * @param \Taupins\FrontBundle\Entity\Status $status
     *
     * @return User
     */
    public function addStatus(\Taupins\FrontBundle\Entity\Status $status)
    {
        $this->statuses[] = $status;

        return $this;
    }

    /**
     * canAddFriend friend
     * 
     * @param \Taupins\Frontbundle\Entity\User $friend
     * @return boolean
     */
    public function canAddFriend(\Taupins\FrontBundle\Entity\User $friend)
    {
        return $this!= $friend && !$this->hasFriend($friend);
    }

    /**
     * hasFriend friend
     * 
     * @param \Taupins\Frontundle\Entity\User $friend
     * @return boolean
     */
    public function hasFriend(\Taupins\FrontBundle\Entity\User $friend)
    {
        return $this->friends->contains($friend);
    }

    /**
     * Remove status
     *
     * @param \Taupins\FrontBundle\Entity\Status $status
     */
    public function removeStatus(\Taupins\FrontBundle\Entity\Status $status)
    {
        $this->statuses->removeElement($status);
    }

    /**
     * Get statuses
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getStatuses()
    {
        return $this->statuses;
    }

    /**
     * Add friend
     *
     * @param \Taupins\FrontBundle\Entity\User $friend
     *
     * @return User
     */
    public function addFriend(\Taupins\FrontBundle\Entity\User $friend)
    {
        $this->friends[] = $friend;

        return $this;
    }

    /**
     * Remove friend
     *
     * @param \Taupins\FrontBundle\Entity\User $friend
     */
    public function removeFriend(\Taupins\FrontBundle\Entity\User $friend)
    {
        $this->friends->removeElement($friend);
    }

    /**
     * Get friends
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFriends()
    {
        return $this->friends;
    }

    /**
     * Add friendsWithMe
     *
     * @param \Taupins\FrontBundle\Entity\User $friendsWithMe
     *
     * @return User
     */
    public function addFriendsWithMe(\Taupins\FrontBundle\Entity\User $friendsWithMe)
    {
        $this->friendsWithMe[] = $friendsWithMe;

        return $this;
    }

    /**
     * Remove friendsWithMe
     *
     * @param \Taupins\FrontBundle\Entity\User $friendsWithMe
     */
    public function removeFriendsWithMe(\Taupins\FrontBundle\Entity\User $friendsWithMe)
    {
        $this->friendsWithMe->removeElement($friendsWithMe);
    }

    /**
     * Get friendsWithMe
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFriendsWithMe()
    {
        return $this->friendsWithMe;
    }

    /**
     * Add comment
     *
     * @param \Taupins\FrontBundle\Entity\Comment $comment
     *
     * @return User
     */
    public function addComment(\Taupins\FrontBundle\Entity\Comment $comment)
    {
        $this->comments[] = $comment;

        return $this;
    }

    /**
     * Remove comment
     *
     * @param \Taupins\FrontBundle\Entity\Comment $comment
     */
    public function removeComment(\Taupins\FrontBundle\Entity\Comment $comment)
    {
        $this->comments->removeElement($comment);
    }

    /**
     * Get comments
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getComments()
    {
        return $this->comments;
    }
}
